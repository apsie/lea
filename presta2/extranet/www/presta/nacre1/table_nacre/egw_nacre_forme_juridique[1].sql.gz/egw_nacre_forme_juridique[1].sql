-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Lun 16 Août 2010 à 14:51
-- Version du serveur: 5.1.36
-- Version de PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `lea`
--

-- --------------------------------------------------------

--
-- Structure de la table `egw_nacre_forme_juridique`
--

CREATE TABLE IF NOT EXISTS `egw_nacre_forme_juridique` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_beneficiaire` bigint(20) NOT NULL DEFAULT '0',
  `pt_fort` text,
  `pt_fort2` text,
  `pt_fort3` text,
  `pt_fort4` text,
  `pt_faible` text,
  `pt_faible2` text,
  `pt_faible3` text,
  `pt_faible4` text,
  `action_mener1` text,
  `action_mener2` text,
  `action_mener3` text,
  `action_mener4` text,
  `delai_realisation1` text,
  `delai_realisation2` text,
  `delai_realisation3` text,
  `delai_realisation4` text,
  `resultat_attendus1` text,
  `resultat_attendus2` text,
  `resultat_attendus3` text,
  `resultat_attendus4` text,
  `diagnostic` text,
  `id_presta` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;
