-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Lun 16 Août 2010 à 14:50
-- Version du serveur: 5.1.36
-- Version de PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `lea`
--

-- --------------------------------------------------------

--
-- Structure de la table `egw_nacre_coherence_hp`
--

CREATE TABLE IF NOT EXISTS `egw_nacre_coherence_hp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_beneficiaire` bigint(20) NOT NULL DEFAULT '0',
  `exp_pro` text,
  `exp_pro2` text,
  `exp_pro3` text,
  `exp_pro4` text,
  `exp_pro5` text,
  `exp_pro6` text,
  `comp_pro` text,
  `comp_pro2` text,
  `comp_pro3` text,
  `comp_pro4` text,
  `comp_pro5` text,
  `comp_pro6` text,
  `form_savoir` text,
  `form_savoir2` text,
  `form_savoir3` text,
  `form_savoir4` text,
  `form_savoir5` text,
  `form_savoir6` text,
  `compet_acq` text,
  `compet_acq2` text,
  `compet_acq3` text,
  `compet_acq4` text,
  `delai_prior` text,
  `delai_prior2` text,
  `delai_prior3` text,
  `delai_prior4` text,
  `type_form` text,
  `type_form2` text,
  `type_form3` text,
  `type_form4` text,
  `elem_port` text,
  `elem_port2` text,
  `elem_port3` text,
  `elem_port4` text,
  `pt_vigilance` text,
  `pt_vigilance2` text,
  `pt_vigilance3` text,
  `pt_vigilance4` text,
  `id_presta` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;
