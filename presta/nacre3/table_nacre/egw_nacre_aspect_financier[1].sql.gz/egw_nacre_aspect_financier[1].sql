-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Lun 16 Août 2010 à 14:50
-- Version du serveur: 5.1.36
-- Version de PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `lea`
--

-- --------------------------------------------------------

--
-- Structure de la table `egw_nacre_aspect_financier`
--

CREATE TABLE IF NOT EXISTS `egw_nacre_aspect_financier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_beneficiaire` bigint(20) NOT NULL DEFAULT '0',
  `apport_pt_forts` text,
  `apport_pt_forts2` varchar(64) NOT NULL,
  `apport_pt_forts3` varchar(64) NOT NULL,
  `apport_pt_forts4` varchar(64) NOT NULL,
  `apportt_pt_faible` text,
  `apportt_pt_faible2` varchar(64) NOT NULL,
  `apportt_pt_faible3` varchar(64) NOT NULL,
  `apportt_pt_faible4` varchar(64) NOT NULL,
  `calcul_pt_fort` text,
  `calcul_pt_fort2` varchar(64) NOT NULL,
  `calcul_pt_fort3` varchar(64) NOT NULL,
  `calcul_pt_fort4` varchar(64) NOT NULL,
  `calcul_pt_faible` text,
  `calcul_pt_faible2` varchar(64) NOT NULL,
  `calcul_pt_faible3` varchar(64) NOT NULL,
  `calcul_pt_faible4` varchar(64) NOT NULL,
  `plan_initial_pt_fort` text,
  `plan_initial_pt_fort2` varchar(64) NOT NULL,
  `plan_initial_pt_fort3` varchar(64) NOT NULL,
  `plan_initial_pt_fort4` varchar(64) NOT NULL,
  `plan_initial_pt_faible` text,
  `plan_initial_pt_faible2` varchar(64) NOT NULL,
  `plan_initial_pt_faible3` varchar(64) NOT NULL,
  `plan_initial_pt_faible4` varchar(64) NOT NULL,
  `plan_trois_ans_pt_fort` text,
  `plan_trois_ans_pt_fort2` varchar(64) NOT NULL,
  `plan_trois_ans_pt_fort3` varchar(64) NOT NULL,
  `plan_trois_ans_pt_fort4` varchar(64) NOT NULL,
  `plan_trois_ans_pt_faible` text,
  `plan_trois_ans_pt_faible2` varchar(64) NOT NULL,
  `plan_trois_ans_pt_faible3` varchar(64) NOT NULL,
  `plan_trois_ans_pt_faible4` varchar(64) NOT NULL,
  `autre_pt_fort` text,
  `autre_pt_fort2` varchar(64) NOT NULL,
  `autre_pt_fort3` varchar(64) NOT NULL,
  `autre_pt_fort4` varchar(64) NOT NULL,
  `autre_pt_faible` text,
  `autre_pt_faible2` varchar(64) NOT NULL,
  `autre_pt_faible3` varchar(64) NOT NULL,
  `autre_pt_faible4` varchar(64) NOT NULL,
  `action_a_mener1` text,
  `action_a_mener2` text,
  `action_a_mener3` text,
  `action_a_mener4` text,
  `delai_de_realisation1` text,
  `delai_de_realisation2` text,
  `delai_de_realisation3` text,
  `delai_de_realisation4` text,
  `resultat_attendus1` text,
  `resultat_attendus2` text,
  `resultat_attendus3` text,
  `resultat_attendus4` text,
  `diagnostic` text,
  `id_presta` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;
